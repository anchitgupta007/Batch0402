import java.util.Scanner;
public class ques3 {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter a number to check if its divisible by 5 and 11:");
		int a = scn.nextInt();
		int b = a;

		if (a % 5 == 0) {
			if (b % 11 == 0) {
				System.out.println("DIVISBLE");
			} else {
				System.out.println("NOT DIVISIBLE");

			}
		}
	}
}