import java.util.Scanner;

public class ques1 {
	public static void main(String[] args) {
		System.out.println("Enter a Number to Check whether its POSITIVE or NEGATIVE:");
		Scanner scn = new Scanner(System.in);
		int a = scn.nextInt();
		if (a >= 0) {
			System.out.println("Positive NUMBER:" + a);
		} else {
			System.out.println("Negative NUMBER:" + a);
		}
	}
}
