import java.util.Scanner;
public class ques7 {
	public static void main(String[] args) {
		Scanner scn= new Scanner(System.in);
		System.out.println("Enter a Number to check if its EVEN or ODD:");
		int n = scn.nextInt();
		if (n > 0) {
			if (n % 2 == 0) {
				System.out.println("Even");
			} else {
				System.out.println("Odd");
			}

		} else {
			System.out.println("num is smaller than 0 or = to 0");
		}
	}
}
