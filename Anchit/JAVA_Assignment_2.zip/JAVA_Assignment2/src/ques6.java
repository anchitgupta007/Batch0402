import java.util.Scanner;
public class ques6 {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter First Number:");
		int a = scn.nextInt();

		System.out.println("Enter Second Number:");
		int b = scn.nextInt();

		if (a == b) 
			System.out.println("Equal");
		
		else if (a != b) 
			System.out.println("Not Equal");
		
		if (a > b) 
			System.out.println("a is greater");
		
		else if (a < b) 
			System.out.println("b is greater");
	}}	