import java.util.Scanner;

	public class ques4_Ladderif {

		public static void main(String[] args) {
			Scanner scn = new Scanner(System.in);
			System.out.println("Enter a Number between 1 - 7:");
			int a = scn.nextInt();
			
			if (a == 1) {
				System.out.println("It's Monday");
			} else if (a == 2) {
				System.out.println("It's Tuesday");
			} else if (a == 3) {
				System.out.println("It's Wednesday");
			} else if (a == 4) {
				System.out.println("It's Thursday");
			} else if (a == 5) {
				System.out.println("It's Friday");
			} else if (a == 6) {
				System.out.println("It's Saturday");
			} else if (a == 7){
				System.out.println("It's Sunday");
			} else {
				System.out.println("Invalid number");
			}
		}
	}