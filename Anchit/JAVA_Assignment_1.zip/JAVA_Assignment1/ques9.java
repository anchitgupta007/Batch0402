import java.util.Scanner;

public class ques9 {
	public static void main(String[] Strings) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter an integer between 0-1000: ");
		int num = scn.nextInt();

		int a = num % 10;
		int e = num / 10;
		int b = e % 10;
		e = e / 10;
		int c = e % 10;
		e = e / 10;
		int d = e % 10;
		int sum = a+b+c+d;
		System.out.println("The sum of all digits entered is: " + sum);

	}
}
