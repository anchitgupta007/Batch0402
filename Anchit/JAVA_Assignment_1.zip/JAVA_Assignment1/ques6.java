import java.util.Scanner;
public class ques6 {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the Radius of circle:");
		double a = scn.nextInt();
		double b = (3.14 * a * a);
		System.out.println("Area of circle is:" + b);
		double c = (2 * 3.14 * a);
		System.out.println("Perimeter of circle is:" + c);
	}
}