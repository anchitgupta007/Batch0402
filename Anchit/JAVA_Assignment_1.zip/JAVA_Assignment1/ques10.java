public class ques10 {

	public static void main(String[] args) {
		string a = java -version;
		System.out.println(a);

	}

}
