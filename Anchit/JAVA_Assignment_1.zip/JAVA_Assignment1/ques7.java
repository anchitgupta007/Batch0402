import java.util.Scanner;

public class ques7 {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter First Number:");
		double a = scn.nextInt();
		System.out.println("Enter Second Number:");
		double b = scn.nextInt();
		System.out.println("Enter Third Number:");
		double c = scn.nextInt();
		double d = (a + b + c) / 3;
		System.out.println("The Average Of Three numbers is:" + d);
	}
}