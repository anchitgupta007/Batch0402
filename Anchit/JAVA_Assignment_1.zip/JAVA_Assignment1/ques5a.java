import java.util.Scanner;
public class ques5a {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Please enter First Number:");
		double a = scn.nextInt();
		System.out.println("Please enter Second Number:");
		double b = scn.nextInt();
		System.out.println("Choose option (1:Addition)(2:Subtraction)(3:Multiplication)(4:Division)(5:Modulus)");
		int calc = scn.nextInt();
		int c = calc;
		switch (calc) {
		case 1:
			System.out.println("Sum is:" + (a + b));
			break;

		case 2:
			System.out.println("Difference is:" + (a - b));
			break;

		case 3:
			System.out.println("Product is:" + (a * b));
			break;

		case 4:
			System.out.println("Division is:" + (a / b));
			break;

		case 5:
			System.out.println("Modulus is:" + (a % b));
			break;

		default:
			System.out.println("Please enter Valid option");
		}
	}
}
