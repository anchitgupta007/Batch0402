import java.util.Scanner;
public class ques5 {
	Scanner q = new Scanner(System.in);
	public static void main(String[] args) {
		System.out
				.println("Please Choose a option (1:Addition)(2:Subtraction)(3:Multiplication)(4:Division)(5:Modulus)");
		int calc = 1;
		switch (calc) {
		case 1:
			System.out.println("Please enter first Number:");
			Scanner a = new Scanner(System.in);
			System.out.println("Please enter second Number:");
			Scanner b = new Scanner(System.in);
			int c = a + b;
			System.out.println("Sum is:" + c);

			break;
		case 2:
			System.out.println("Please enter first Number:");
			Scanner a1 = new Scanner(System.in);
			System.out.println("Please enter second Number:");
			Scanner b1 = new Scanner(System.in);
			int c1 = a1 - b1;
			System.out.println("Difference is:" + c);

			break;
		case 3:
			System.out.println("Please enter first Number:");
			Scanner a11 = new Scanner(System.in);
			System.out.println("Please enter second Number:");
			Scanner b11 = new Scanner(System.in);
			int c11 = a11 * b11;
			System.out.println("Product is:" + c);

			break;
		case 4:
			System.out.println("Please enter first Number:");
			Scanner a111 = new Scanner(System.in);
			System.out.println("Please enter second Number:");
			Scanner b111 = new Scanner(System.in);
			int c111 = a111 / b111;
			System.out.println("Division is:" + c111);

			break;

		case 5:
			System.out.println("Please enter first Number:");
			Scanner a1111 = new Scanner(System.in);
			System.out.println("Please enter second Number:");
			Scanner b1111 = new Scanner(System.in);
			int c1111 = a1111 % b1111;
			System.out.println("Modulus is:" + c1111);
		
			break;
		default:
			System.out.println("Please enter a Valid number");

		}
		}
	}
}