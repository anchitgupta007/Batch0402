class ques2 {
	public static void main(String[] args) {
		int a = 175;
		int b = 25;
		int c = a + b;
		System.out.println(c);
	}
}