class ques4{//				//a_part
	public static void main(String[]args){
	int a=-5;
	int b=8;
	int c=a+b;
	int d=c*6;
	System.out.println(d);
		
	int a1=55;//			//b_part
	int b1=9;
	int c1=a1+b1;
	int d1=c1%9;
	System.out.println(d1);
		
	int a2=20;//			//c_part
	int b2=-3;
	int c2=a2+-3;
	double d2=c2*5;
	double e2=d2/8;
	System.out.println(e2);
	
	int a3=5;			//d_part
	int b3=15;
	int c3=a3+b3;
	int d3=c3/3;
	int e3=d3*2;
	double f3=e3-8;
	double g3=f3%3;
	System.out.println(g3);
	}
}