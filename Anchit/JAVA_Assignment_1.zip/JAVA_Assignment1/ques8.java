import java.util.Scanner;

public class ques8 {
	public static void main(String[] args) {

		Scanner scn = new Scanner(System.in);
		System.out.println("Enter Length of Rectangle:");
		double a = scn.nextInt();
		System.out.println("Enter Breadth of Rectangle:");
		double b = scn.nextInt();
		double c = a * b;
		System.out.println("Area of Rectangle is: " + c);
		double d = 2 * (a + b);
		System.out.println("Perimeter of Rectangle is: " + d);
	}
}
