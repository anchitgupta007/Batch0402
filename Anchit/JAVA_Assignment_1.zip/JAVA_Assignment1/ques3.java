class ques3{
	public static void main(String[]args){
	int a=9999;
	int b=3;
	int c=a/b;
	System.out.println(c);
	}
}